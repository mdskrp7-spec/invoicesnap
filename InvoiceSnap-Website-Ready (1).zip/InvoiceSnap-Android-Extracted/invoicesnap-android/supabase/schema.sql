-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  number text not null,
  customer text not null,
  email text,
  description text,
  amount numeric(14,2) not null check (amount > 0),
  currency text not null default 'INR',
  issued date not null,
  due date not null,
  status text not null default 'pending' check (status in ('pending','paid')),
  razorpay_order_id text,
  razorpay_payment_id text,
  last_reminder_sent_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id, number),
  check (due >= issued)
);

create index if not exists invoices_user_created_idx on public.invoices(user_id, created_at desc);
create index if not exists invoices_due_pending_idx on public.invoices(due) where status = 'pending';

alter table public.invoices enable row level security;
drop policy if exists "Users can read their invoices" on public.invoices;
create policy "Users can read their invoices" on public.invoices for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can create their invoices" on public.invoices;
create policy "Users can create their invoices" on public.invoices for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update their invoices" on public.invoices;
create policy "Users can update their invoices" on public.invoices for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete their invoices" on public.invoices;
create policy "Users can delete their invoices" on public.invoices for delete to authenticated using (auth.uid() = user_id);

-- The service-role key is used only on the server. Never expose it in browser code.
