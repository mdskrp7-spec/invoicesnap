// Set this to your deployed InvoiceSnap Node.js backend URL.
// Example: https://api.yourdomain.com
// Do not include a trailing slash. Keep HTTPS in production.
window.INVOICESNAP_API_BASE_URL = "https://YOUR-INVOICESNAP-BACKEND-DOMAIN";
