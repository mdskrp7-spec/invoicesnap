# Go-live checklist

- [ ] Create Supabase project and run `supabase/schema.sql`
- [ ] Configure frontend Supabase URL and anon key
- [ ] Set server Supabase URL, anon key and service-role key
- [ ] Create Razorpay account; test checkout with test keys
- [ ] Configure Razorpay webhook and test captured-payment event
- [ ] Verify Resend sending domain and set sender identity
- [ ] Test signup, login, logout and password/email confirmation settings
- [ ] Test user A cannot read user B invoices
- [ ] Test invoice validation and duplicate invoice number handling
- [ ] Test reminder schedule, sender identity and opt-out policy
- [ ] Deploy on HTTPS and configure webhook URL
- [ ] Add backups, monitoring, logs, privacy policy and terms
- [ ] Switch Razorpay to live only after merchant activation and end-to-end testing

## Simple UPI payments
- [ ] Set `UPI_ID` to your business UPI ID.
- [ ] Set `UPI_PAYEE_NAME` to your business display name.
- [ ] Test a small payment on a phone with a UPI app.
- [ ] Verify the transaction in your bank/UPI app before marking the invoice paid.
