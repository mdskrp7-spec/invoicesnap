require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { createClient } = require("@supabase/supabase-js");
const Razorpay = require("razorpay");
const { Resend } = require("resend");
const cron = require("node-cron");
const crypto = require("crypto");
const path = require("path");

const required = ["SUPABASE_URL","SUPABASE_ANON_KEY","SUPABASE_SERVICE_ROLE_KEY"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing required environment variables:", missing.join(", "));
  console.error("Copy .env.example to .env and fill in your Supabase values.");
  process.exit(1);
}
const app = express();
// Allow the bundled Capacitor WebView to call this separately hosted API.
// Add your deployed website origin(s) to CORS_ALLOW_ORIGINS as comma-separated HTTPS URLs.
const allowedOrigins = new Set(["capacitor://localhost", "http://localhost", "https://localhost", ...(process.env.CORS_ALLOW_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean)]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, OPTIONS");
  }
  if (req.method === "OPTIONS") return res.sendStatus(origin && allowedOrigins.has(origin) ? 204 : 403);
  next();
});
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.static(path.join(__dirname, "www")));
app.use((req,res,next) => {
  if (req.originalUrl.startsWith("/api/webhooks/razorpay")) {
    return express.raw({ type: "application/json" })(req,res,next);
  }
  return express.json({ limit: "100kb" })(req,res,next);
});
const supabaseAdmin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
const supabasePublic = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;
const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false });
app.use("/api", limiter);

function fail(res, status, message) { return res.status(status).json({ error: message }); }
async function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return fail(res, 401, "Sign in to continue.");
  const { data, error } = await supabasePublic.auth.getUser(token);
  if (error || !data.user) return fail(res, 401, "Your session is invalid or expired.");
  req.user = data.user;
  next();
}
const clean = s => String(s || "").trim();
const validDate = s => /^\d{4}-\d{2}-\d{2}$/.test(String(s));
function validateInvoice(body) {
  const customer = clean(body.customer), number = clean(body.number);
  const amount = Number(body.amount);
  if (!customer || customer.length > 120) return "Enter a customer name (up to 120 characters).";
  if (!number || number.length > 32) return "Enter an invoice number (up to 32 characters).";
  if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000) return "Enter a valid invoice amount.";
  if (!validDate(body.issued) || !validDate(body.due) || body.due < body.issued) return "Enter valid dates; due date cannot precede issue date.";
  if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) return "Enter a valid customer email.";
  return null;
}
app.get("/api/config", (_req,res) => res.json({ supabaseUrl: process.env.SUPABASE_URL, supabaseAnonKey: process.env.SUPABASE_ANON_KEY, razorpayKeyId: process.env.RAZORPAY_KEY_ID || null, upiId: process.env.UPI_ID || null, upiPayeeName: process.env.UPI_PAYEE_NAME || "InvoiceSnap" }));
app.get("/api/invoices", auth, async (req,res) => {
  const { data,error } = await supabaseAdmin.from("invoices").select("*").eq("user_id",req.user.id).order("created_at",{ascending:false});
  if(error) return fail(res,500,"Could not load invoices.");
  res.json({ invoices:data });
});
app.post("/api/invoices", auth, async (req,res) => {
  const issue = validateInvoice(req.body || {});
  if(issue) return fail(res,400,issue);
  const row = {
    user_id:req.user.id, number:clean(req.body.number), customer:clean(req.body.customer),
    email:clean(req.body.email).toLowerCase() || null, description:clean(req.body.description).slice(0,500),
    amount:Number(req.body.amount), currency:"INR", issued:req.body.issued, due:req.body.due,
    status:req.body.status === "paid" ? "paid" : "pending"
  };
  const { data,error } = await supabaseAdmin.from("invoices").insert(row).select("*").single();
  if(error) return fail(res,error.code==="23505"?409:500,error.code==="23505"?"That invoice number already exists.":"Could not save invoice.");
  res.status(201).json({ invoice:data });
});
app.patch("/api/invoices/:id/status", auth, async (req,res) => {
  const status = req.body.status;
  if(!["pending","paid"].includes(status)) return fail(res,400,"Unsupported invoice status.");
  const { data,error } = await supabaseAdmin.from("invoices").update({status}).eq("id",req.params.id).eq("user_id",req.user.id).select("*").single();
  if(error || !data) return fail(res,404,"Invoice not found.");
  res.json({invoice:data});
});
app.delete("/api/invoices/:id", auth, async (req,res) => {
  const { error } = await supabaseAdmin.from("invoices").delete().eq("id",req.params.id).eq("user_id",req.user.id);
  if(error) return fail(res,500,"Could not delete invoice.");
  res.json({ok:true});
});
app.post("/api/payments/order", auth, async (req,res) => {
  if(!razorpay) return fail(res,503,"Razorpay is not configured yet.");
  const { invoiceId } = req.body || {};
  const { data:inv,error } = await supabaseAdmin.from("invoices").select("*").eq("id",invoiceId).eq("user_id",req.user.id).single();
  if(error || !inv) return fail(res,404,"Invoice not found.");
  if(inv.status==="paid") return fail(res,409,"This invoice is already paid.");
  try {
    const order = await razorpay.orders.create({ amount:Math.round(Number(inv.amount)*100), currency:"INR", receipt:inv.number.slice(0,40), notes:{invoice_id:inv.id,user_id:req.user.id} });
    const { error:saveError } = await supabaseAdmin.from("invoices").update({razorpay_order_id:order.id}).eq("id",inv.id).eq("user_id",req.user.id);
    if(saveError) throw saveError;
    res.json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:process.env.RAZORPAY_KEY_ID,invoice:{id:inv.id,number:inv.number,customer:inv.customer,email:inv.email}});
  } catch(e) { console.error("Razorpay order error",e.message); fail(res,502,"Could not start checkout."); }
});
app.post("/api/payments/verify", auth, async (req,res) => {
  const { razorpay_order_id,razorpay_payment_id,razorpay_signature,invoiceId } = req.body || {};
  if(!process.env.RAZORPAY_KEY_SECRET) return fail(res,503,"Payment gateway is not configured.");
  const expected = crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
  const a=Buffer.from(expected), b=Buffer.from(String(razorpay_signature||""));
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return fail(res,400,"Payment signature could not be verified.");
  const {data:inv,error} = await supabaseAdmin.from("invoices").update({status:"paid",razorpay_payment_id}).eq("id",invoiceId).eq("user_id",req.user.id).eq("razorpay_order_id",razorpay_order_id).select("*").single();
  if(error || !inv) return fail(res,400,"Payment could not be matched to this invoice.");
  res.json({ok:true,invoice:inv});
});
// Razorpay webhook: configure this URL in the Razorpay dashboard.
// Raw body is required for signature verification, so this route reads it before JSON middleware.
app.post("/api/webhooks/razorpay", async (req,res) => {
  const secret=process.env.RAZORPAY_WEBHOOK_SECRET;
  if(!secret) return fail(res,503,"Webhook secret is not configured.");
  const signature=req.headers["x-razorpay-signature"] || "";
  const expected=crypto.createHmac("sha256",secret).update(req.body).digest("hex");
  const a=Buffer.from(expected),b=Buffer.from(signature);
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return fail(res,400,"Invalid webhook signature.");
  let event;
  try { event=JSON.parse(req.body.toString("utf8")); }
  catch { return fail(res,400,"Invalid webhook payload."); }
  if(event.event==="payment.captured") {
    const payment=event.payload?.payment?.entity;
    const invoiceId=payment?.notes?.invoice_id;
    if(invoiceId) {
      await supabaseAdmin.from("invoices").update({status:"paid",razorpay_payment_id:payment.id}).eq("id",invoiceId).eq("razorpay_order_id",payment.order_id);
    }
  }
  res.json({received:true});
});
async function sendDueReminders() {
  if(!resend) return;
  const today=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());
  const {data:rows,error}=await supabaseAdmin.from("invoices").select("id,user_id,number,customer,email,amount,currency,due").eq("status","pending").lte("due",today).not("email","is",null).is("last_reminder_sent_at",null);
  if(error) { console.error("Reminder query failed",error.message); return; }
  for(const inv of rows||[]) {
    try {
      await resend.emails.send({from:process.env.EMAIL_FROM,to:inv.email,subject:`Payment reminder for invoice ${inv.number}`,html:`<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#20283a"><h2>Payment reminder</h2><p>Hello ${escapeHtml(inv.customer)},</p><p>This is a friendly reminder that invoice <b>${escapeHtml(inv.number)}</b> for <b>${formatINR(inv.amount)}</b> was due on ${escapeHtml(inv.due)}.</p><p>Please contact the sender if you have already made this payment.</p><p>Thank you.</p><small>Sent by InvoiceSnap on behalf of your service provider.</small></div>`});
      await supabaseAdmin.from("invoices").update({last_reminder_sent_at:new Date().toISOString()}).eq("id",inv.id);
    } catch(e) { console.error("Reminder failed for",inv.id,e.message); }
  }
}
function escapeHtml(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function formatINR(n){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR"}).format(n);}
if(process.env.REMINDER_CRON) cron.schedule(process.env.REMINDER_CRON,sendDueReminders,{timezone:"Asia/Kolkata"});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"www","index.html")));
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`InvoiceSnap running on http://localhost:${port}`));
