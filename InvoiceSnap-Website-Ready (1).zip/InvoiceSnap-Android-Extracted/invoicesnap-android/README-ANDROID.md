# InvoiceSnap Android project (Capacitor)

This package wraps the existing InvoiceSnap web interface in a native Android shell using Capacitor. The Android app uses the existing Node.js backend, Supabase database/auth, UPI deep links and optional Razorpay checkout.

## Important architecture

- `www/` is the app's bundled web interface.
- `www/runtime-config.js` tells the Android app where its HTTPS Node.js API is hosted.
- `server.js` is the separate Node.js backend. It must be deployed to an HTTPS host; it does not run inside the Android app.
- Supabase, email reminders and payment secrets stay on the server. Never put the Supabase service-role key, Razorpay secret, Resend key or webhook secret in the Android app.

## 1. Configure the API URL

Deploy the backend first using the included `server.js`, `supabase/schema.sql` and `.env.example` (the SQL schema is in `supabase/`). Set all required environment variables on your hosting provider. Set `CORS_ALLOW_ORIGINS` only if you also use a separate website frontend; the Capacitor WebView origins are allowed by the included backend middleware.

Then edit `www/runtime-config.js` and replace the placeholder with your real HTTPS backend URL, for example:

```js
window.INVOICESNAP_API_BASE_URL = "https://api.yourdomain.com";
```

Do not leave the placeholder. The app cannot sign in or load invoices until the API and Supabase are configured.

## 2. Install Android build tools

On a Windows, macOS or Linux computer install:

1. Node.js 20 or newer.
2. Android Studio (stable release) and its Android SDK.
3. A compatible JDK (Android Studio's bundled JBR is usually suitable).

Open a terminal in this folder and run:

```bash
npm install
npm run android:setup
npm run android:sync
npm run android:open
```

`android:setup` generates the native `android/` Gradle project using Capacitor. It requires internet access the first time so npm can download Capacitor packages. Android Studio will then download any required Android Gradle/SDK components.

## 3. Test on a phone

In Android Studio, enable USB debugging on an Android phone, connect it, select the device, and press Run. Test:

- Sign-up, email confirmation and sign-in
- Create, search and update invoices
- UPI app handoff and manual payment confirmation
- Razorpay checkout if enabled
- API behavior on mobile data and Wi-Fi

UPI handoff does not automatically verify a payment. Confirm receipt in your bank/payment provider before marking an invoice paid.

## 4. Generate a Play Store bundle (.aab)

In Android Studio choose **Build → Generate Signed Bundle / APK → Android App Bundle**. Create and securely back up a release signing key. Select the release variant and generate the `.aab`. Never share the keystore or passwords.

You can also use Gradle after the native project has been generated and signing is configured:

- Windows: `npm run android:build`
- macOS/Linux: `npm run android:build:linux`

The release bundle is normally created at `android/app/build/outputs/bundle/release/app-release.aab`.

## Before Play Store submission

- Replace the default app icon and create store screenshots/feature graphic.
- Set the final application ID before the first Play Store upload; changing it later creates a different app.
- Add a public privacy policy and accurate Data safety disclosures.
- Complete Play Console app access, content rating, target API and testing requirements.
- Test payment, authentication and reminder flows on real devices.
- Keep all backend endpoints HTTPS and ensure account deletion/data deletion obligations are met.

## What this package does not do automatically

It does not create your Google Play developer account, deploy the backend, provision Supabase/Razorpay/Resend, create a signing key, generate a signed release AAB, or submit the app to Google. Those require your accounts, secrets and Android build environment.
